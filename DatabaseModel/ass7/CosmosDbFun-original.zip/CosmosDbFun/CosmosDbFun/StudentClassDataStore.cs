﻿using Microsoft.Azure.Cosmos;
using System;
using System.Threading.Tasks;

namespace CosmosDbFun
{
    public class StudentClassDataStore
    {
        private Container container;

        public StudentClassDataStore(Container container)
        {
            this.container = container;
        }

        public async Task<StudentClassRecord> CreateStudentClassRecord(StudentClassRecord studentClassRecord)
        {
            if (studentClassRecord == null) throw new ArgumentNullException(nameof(studentClassRecord));

            Console.WriteLine($"Creatung Student {studentClassRecord.Id} for Class {studentClassRecord.ClassId}");
            return await container.CreateItemAsync(studentClassRecord);
        }
    }
}
