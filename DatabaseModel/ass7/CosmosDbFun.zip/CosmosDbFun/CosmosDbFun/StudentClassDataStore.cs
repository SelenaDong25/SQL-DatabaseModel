﻿using Microsoft.Azure.Cosmos;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CosmosDbFun
{
    public class StudentClassDataStore
    {
        private Container container;

        public StudentClassDataStore(Container container)
        {
            this.container = container;
        }

        public async Task<StudentClassRecord> CreateStudentClassRecord(StudentClassRecord studentClassRecord)
        {
            if (studentClassRecord == null) throw new ArgumentNullException(nameof(studentClassRecord));

            Console.WriteLine($"Creatung Student {studentClassRecord.Id} for Class {studentClassRecord.ClassId}");
            return await container.CreateItemAsync(studentClassRecord);
        }

        public async Task<StudentClassRecord> GetStudentClassRecord(string studentId, string classId)
        {
            if (string.IsNullOrEmpty(studentId)) throw new ArgumentNullException(nameof(studentId));
            if (string.IsNullOrEmpty(classId)) throw new ArgumentNullException(nameof(classId));

            Console.WriteLine($"Reading Student {studentId} for Class {classId}");
            return await container.ReadItemAsync<StudentClassRecord>(studentId, new PartitionKey(classId));
        }

        public async Task<List<StudentClassRecord>> GetStudents(string classId)
        {
            if (string.IsNullOrEmpty(classId)) throw new ArgumentNullException(nameof(classId));

            QueryDefinition queryDefinition = new QueryDefinition("SELECT * from c where c.ClassId = @classId")
                .WithParameter("@classId", classId);

            List<StudentClassRecord> students = new List<StudentClassRecord>();

            using (FeedIterator<StudentClassRecord> feedIterator = container.GetItemQueryIterator<StudentClassRecord>(
                queryDefinition,
                    null,
                    new QueryRequestOptions() { PartitionKey = new PartitionKey(classId) }))
            {
                while (feedIterator.HasMoreResults)
                {
                    var feedIteratorData = await feedIterator.ReadNextAsync();
                    foreach (var item in feedIteratorData)
                    {
                        students.Add(item);
                        Console.WriteLine(item.Id);
                    }
                }
            }
            return students;
        }



    }
}
